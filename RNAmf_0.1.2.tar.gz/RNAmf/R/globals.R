globalVariables(unique(c(
  # ALC_two_level:
  "j",
  # ALMC_two_level:
  "j",
  # ALM_two_level:
  "i"
)))
